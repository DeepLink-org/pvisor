"""Do not mistake an early guest shell or a console line for a complete OS."""

import json

import pytest
from ubuntu_baselines import protocol_line, validate_os


def proof(**overrides):
    value = {
        "os_release": 'NAME="Ubuntu"\nVERSION_ID="26.04"\n',
        "kernel": "7.0.0-34-generic",
        "pid1": "systemd",
        "multi_user": "active",
        "network_online": "active",
        "cloud_final": "active",
        "ssh_socket": "active",
    }
    return "REFERENCE_OS_READY " + json.dumps(value | overrides)


def test_full_distribution_readiness():
    assert validate_os(proof())["kernel"] == "7.0.0-34-generic"


@pytest.mark.parametrize(
    "change",
    [
        {"pid1": "sh"},
        {"kernel": "6.12.109"},
        {"os_release": 'NAME="Fedora"'},
        {"multi_user": "activating"},
        {"network_online": "inactive"},
        {"cloud_final": "failed"},
        {"ssh_socket": "inactive"},
    ],
)
def test_incomplete_or_trimmed_guest_does_not_pass(change):
    with pytest.raises(ValueError):
        validate_os(proof(**change))


@pytest.mark.parametrize("output", ["REFERENCE_READY", proof() + "\n" + proof()])
def test_os_proof_required_once(output):
    with pytest.raises(ValueError):
        validate_os(output)


def test_named_journal_record_preserves_protocol():
    assert (
        protocol_line("[   6.123456] reference-bench[123]: REFERENCE_READY\r\n")
        == "REFERENCE_READY"
    )
    assert protocol_line("REFERENCE_READY\r\n") == "REFERENCE_READY"
    assert protocol_line("[   6.123456] other-unit[123]: REFERENCE_READY") != "REFERENCE_READY"


def test_getty_controls_before_named_record():
    prefix = "\x1b[!p\x1b]104\x1b\\\x1b[0m\x1b[6n"
    assert (
        protocol_line(prefix + "[ 12.123456] reference-bench[123]: REFERENCE_READY")
        == "REFERENCE_READY"
    )
    assert (
        protocol_line(prefix + "[ 12.123456] other-unit[123]: REFERENCE_READY") != "REFERENCE_READY"
    )


def test_partial_benchmark_cannot_be_published():
    from render_ubuntu_baselines import validate_complete

    report = {
        "arguments": {"modes": "ready", "backends": "native", "samples": "2"},
        "capabilities": {"ready/native": {"state": "available"}},
        "rows": [{"mode": "ready", "backend": "native", "trial": 0, "correctness": "passed"}],
    }
    with pytest.raises(ValueError, match="Incomplete"):
        validate_complete(report)
    report["rows"].append(dict(report["rows"][0], trial=1))
    validate_complete(report)
    report["rows"][1]["correctness"] = "failed"
    with pytest.raises(ValueError, match="Failed workloads"):
        validate_complete(report)


def test_failed_preflight_has_no_latency_samples():
    from render_ubuntu_baselines import validate_complete

    report = {
        "arguments": {"modes": "claude", "backends": "pvisor-vm-hostroot", "samples": "10"},
        "capabilities": {"claude/pvisor-vm-hostroot": {"state": "failed-preflight"}},
        "rows": [],
    }
    validate_complete(report)
    report["rows"].append(
        {"mode": "claude", "backend": "pvisor-vm-hostroot", "trial": 0, "correctness": "passed"}
    )
    with pytest.raises(ValueError, match="Failed preflight"):
        validate_complete(report)


def test_login_prompt_before_named_record():
    line = "pvisor-ubuntu-reference login: [ 14.820672] reference-bench[1226]: REFERENCE_READY"
    assert protocol_line(line) == "REFERENCE_READY"
    assert protocol_line(line.replace("reference-bench", "other-unit")) != "REFERENCE_READY"
    assert protocol_line("pvisor-ubuntu-reference login: REFERENCE_READY") != "REFERENCE_READY"
